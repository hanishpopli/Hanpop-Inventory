export default function Home() {
  return (
    <div>
      <h1>Hanpop Inventory Dashboard</h1>
      <p>Welcome! This is your restaurant management panel.</p>
    </div>
  );
}
